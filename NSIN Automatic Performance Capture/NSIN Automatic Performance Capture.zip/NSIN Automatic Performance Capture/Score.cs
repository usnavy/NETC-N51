using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//score system


public class Score : MonoBehaviour
{
   
    public Text scoreText;
    public Transform CubeYellow;
    //CubeYellow is the player
    //we can use fire extingushier as the player object as well. 




    void Update(){


        //scoreText = (GameObject.FindWithTag("CubeYellow")).GetComponent<>();
        scoreText.text = CubeYellow.position.ToString();
        //outputting the user coordinates in 3 dimension


// unfinished. need to add the amount of flame has been extinguished 
//getcomponent()
    
    }



}
