# Unity-3D
code for Unity and the HoloLens 2

how to run unity project: 
simply add/drag the project folder to Unity hub, then import downloaded MRTK package to the same project path. 
to run MRTK successfully, it requires: mrtk toolkit, mrtk foundation, mrtk asset, openXR plugin.
After all steps above, build setting need to set as universal windows platform for project development. the rest setting could be found in MRTK microsoft offical website: https://docs.microsoft.com/en-us/windows/mixed-reality/mrtk-unity/?view=mrtkunity-2021-05
Project setting could be found in edit, and openXR plug-in need to change to corresponding needs.

project could be run in unity test mode and hololens. Check below for a clearer description on how to run hololens 2


-----------------------------
hand tracking code pass through, import hand track script, then import configure MRTK mesh resources, it should be working good.
if wanna coordinate with movement trajectory analysis, it will need further development

------------------------

fire extinguish is able to be grab, move and rotate now.
active profile has been assigned now, issue fixed.

--------------------------------------
UI menu

input/diagonstics/configuration should be clone in the same profile
  - input data provider ports: remove windows speech input/dictation input

interactable menu could be used from the following MRTK pack: 
these prefabs are built to support inputs
  -MRTK foundation
    -SDK
      -Features
        -UX
          -interactable
            -prefabs
 dont forget to change position to avoid menus got too close to user's front when headset is on.
 then start change the input simulation
 
 a notification panel/window is linked to dynamic button 1, but test failed. need to figure out the issue.

----------------------------


fix prefebs components materials issue
  ---- prefebs materials went pink because universal render pipeline isn't working correct
  ---- need to change render pipeline Uiversal render pipeline
      --------1. go to package manager, change tab to Packages: Unity Registry
      --------2. download Universal RP, then install
      --------3. go to project setting, graph section, then change the scriptable render pipeline setting from none to unviersalRenderPipelineAsset
      --------4. go to project window, click asset folder. then right click, creat-- Rendering ---- universal rendering pipeline, create UniversalRenderPipelineAsset.asset. 
      --------5. go to edit. then go to the bottom click Render pipeline, ----Unversal render pipeline. then upgrade project materials to univesalIRP materials. proceed to overwrite the materials in project.
     ---------6. right click to creat a new material, then simply drag the new material to all subjects are in pink to change colors.
     

-----------
input system--- collecting data from sensors, then send the recorded data to Hololens 2. and outputting data to Hololens notification windows

we are having trouble to fully establish an input system to connect hardware portion to hololens via wifi at this moment due to the lack of knowledge and time shortage, but a rough gamemanager script have been written and only need to import to object.
-----------
