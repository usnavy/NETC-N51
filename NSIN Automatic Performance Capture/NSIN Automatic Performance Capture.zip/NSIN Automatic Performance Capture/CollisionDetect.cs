using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//detect objects collision and output the amount of flame was off


public class CollisionDetect : MonoBehaviour
{
     

    public int flameNum = 0;

    // Update is called once per frame


    void OnCollisionEnter(Collision col) {

         


        if (col.gameObject.name == "CubeRed") {
            //detect collision happen to object called CubeRed


            //Destroy(col.gameObject);
            //if condition runs, destry the object call CubeRed

            flameNum +=1;
            return;

        }
    }

   

}
