// GameManager
//rough game manager


public class GameManager : MonoBehaviour{

    static public GameManager  gm;
    // one game only allow to have one game manager
    
    public GameObject player;
    public int TargetScore=10;
    //goal of total fire 🔥 
    
    
    private int currentScore;
    //how many fire has been extinguished
    
    
    public enum GameState{Playing,GameOver,Winning};
    //game state enumeration
    public GameState gameState;
    //game current state
    
    
    public Text ScoreText;
    //GUI-player score output
   
   
   
    //private int GVS;
    //private int HeartRateSensor;
    //private int PluseSensor;
    //all sensors above connect to GUI
    //unfinished


    void Start (){
    
    gm=GetComponet<GameManager>();
    
    if (player== null)
        player == GameObject.FindGameObjectWithTag("Player");
    //get player with tag'player'
        
        currentScore =0;
        //initial score = 0
        
    
    }



    void Update(){
      switch (gameState){
  
  //build different case to jump to different states
  
  
      case GameState.Playing:
         scoreText.text = "Score:" + currentScore;
      //GUI---game score
      
         if (currentScore >= TargetScore)
             gm.gameState = GameState.Winning;
              break; 
       //   if the flame is extingushed to pre-set amount(5), player win the game
  
      case GameState.Winning:
         SceneManager.LoadScene("Nice");
         break;
      
      case GameState.GameOver:
         SceneManager.LoadScene("Nice");
          break;
  
            }


          }


    public void AddScore(int value){
          currentScore =+value;
      }
   

}



  
