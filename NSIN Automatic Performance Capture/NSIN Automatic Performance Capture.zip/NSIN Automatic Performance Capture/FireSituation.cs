//detect if there is fire or not
// assuming box set to have 5 fires on. if fire is <-0, which means no fire is on, so FireOn= ture; else Fireon=false


public int fireNum=5;
public bool FireOn = true;

void Update() {
    if (fireNum <=0)
        FireOn = false; 
}   // Update() ---- detect fire situation


public void TakeOffFire(int FireOff){
    fireNum -= FireOff;
    if(fireNum <0)
       fireNum =0;
  
}
