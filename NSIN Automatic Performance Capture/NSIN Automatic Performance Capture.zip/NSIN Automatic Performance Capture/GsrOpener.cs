using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GsrOpener : MonoBehaviour
{
    public Object Panel;

    public void OpenGsrNotification() {

        if (Panel != null) {
            Panel.setActive(true);

        }
    
    }
}
 
